#include "pico/stdlib.h"
#include "lib/st7735.h"
#include "pico/stdio.h"
#include <hardware/uart.h>
#include <stdio.h>
#include <inttypes.h>

uint8_t vote(uint8_t v1, uint8_t v2, uint8_t v3){
    if (v1 == v2 || v1 == v3){
        return v1;
    }
    else if (v2 == v3){
        return v2;
    }
    //None of the three agree (which is really not helpful) do a bitwise vote instead.
    uint8_t res = 0;
    uint16_t mask = 0x1;
    while (mask < 256){
        if ((v1 & mask) == (v2 & mask) || (v1 & mask) == (v3 & mask)){
            res += (v1 & mask);
        }
        else {
            //There's only two options for a single bit, so given v1 != v2 and v1 != v3, v2 == v3.
            res += (v2 & mask);
        }
        mask = mask << 1;
    }

    return res;
}


void setScreenCol(uint8_t r, uint8_t g, uint8_t b){
    ST7735_FillScreen((uint16_t) ST7735_COLOR565(r, g, b));
}

void getScreenCol(uart_inst_t* bus, void (*callback)(uint8_t, uint8_t, uint8_t)){
    uint32_t i = 0;
    uint8_t c;
    //The compiler has forced my hand :(
    struct MemAlignBlock {
        uint8_t col[12]; //What we expect to read (9x col bytes, then 3x termination bytes)
        volatile uint32_t debug;
        volatile void (*callback)(uint8_t, uint8_t, uint8_t);
    };

    struct MemAlignBlock blck;

    blck.debug = 0;
    blck.callback = callback;

    while (true){
        c = uart_getc(bus);
        if (c == 0xa){
            break; //We only actually care about the first 9 bytes.
        }
        blck.col[i] = c;
        i++;
    }

    uint8_t r;
    uint8_t g;
    uint8_t b;
    r = vote(blck.col[0], blck.col[3], blck.col[6]);
    g = vote(blck.col[1], blck.col[4], blck.col[7]);
    b = vote(blck.col[2], blck.col[5], blck.col[8]);

    //If we have debug on, print out a couple pointers.
    if (blck.debug){
        char debugInfo[50];
        ST7735_FillScreen(ST7735_BLACK);
        sprintf(debugInfo, "Chars*: %p", blck.col);
        ST7735_WriteString(0, 0, debugInfo, Font_16x26, ST7735_GREEN, ST7735_BLACK);
        sleep_ms(5000);
        ST7735_FillScreen(ST7735_BLACK);
        sprintf(debugInfo, "Callback*: %p", blck.callback);
        ST7735_WriteString(0, 0, debugInfo, Font_16x26, ST7735_GREEN, ST7735_BLACK);
        sleep_ms(5000);
        ST7735_FillScreen(ST7735_BLACK);
        sprintf(debugInfo, "Debug: %lu", blck.debug);
        ST7735_WriteString(0, 0, debugInfo, Font_16x26, ST7735_GREEN, ST7735_BLACK);
        sleep_ms(5000);
        ST7735_FillScreen(ST7735_BLACK);
    }

    //Call our callback function
    (blck.callback)(r,g,b);

}

int main() {
    stdio_init_all();

    ST7735_Init();  // Initialise the screen
    ST7735_FillScreen(ST7735_BLACK);

    ST7735_WriteString(0, 0, "Ready.", Font_16x26, ST7735_RED, ST7735_BLACK);

    uart_init(uart0, 115200);

    gpio_set_function(0, GPIO_FUNC_UART);
    gpio_set_function(1, GPIO_FUNC_UART);

    while (true){
        getScreenCol(uart0, setScreenCol);
    }

    return 0;
}