#include "pico/stdlib.h"
#include "pico/stdio.h"
#include "rgbled.pio.h"
#include <hardware/uart.h>
#include <hardware/clocks.h>
#include <hardware/pio.h>
#include <stdio.h>
#include <stdlib.h>


//Source: https://www.raspberrypi.com/news/neopixel-dithering-with-pico/
static inline void put_pixel(uint32_t pixel_grb) {
    pio_sm_put_blocking(pio0, 0, pixel_grb << 8u);
}
static inline uint32_t urgb_u32(uint8_t r, uint8_t g, uint8_t b) {
    return
            ((uint32_t) (r) << 8) |
            ((uint32_t) (g) << 16) |
            (uint32_t) (b);
}



void sendUARTCol(uart_inst_t* bus, char r, char g, char b){
    //Check for no 0xA, which is our termination char. If there is, subtract 1 from it.
    if (r == 0xa){
        r++;
    }
    if (g == 0xa){
        g++;
    }
    if (b == 0xa){
        b++;
    }
    //Write the colour 3 times in a row for redundancy
    for (char i = 0; i<3;i++) {
        uart_putc_raw(bus, r);
        uart_putc_raw(bus, g);
        uart_putc_raw(bus, b);
    }
    //Write the termination char (also 3 times)
    for (char i = 0; i<3; i++){
        uart_putc_raw(bus, 0xa);
    }
}

int main() {

    static const uint led_pin = 28;

    PIO pio = pio0;
    int sm = 0;
    uint offset = pio_add_program(pio, &ws2812_program);
    ws2812_program_init(pio, sm, offset, led_pin, 1000000, false);

    // Start running our PIO program in the state machine
    //pio_sm_set_enabled(pio, sm, true);


    stdio_init_all();
    uart_init(uart0, 115200);

    gpio_set_function(0, GPIO_FUNC_UART);
    gpio_set_function(1, GPIO_FUNC_UART);

    gpio_init(20);

    gpio_set_function(20, GPIO_IN);

    char r,g,b;

    while (true){

        //Generate an... unpredicatable stream of colours to verify this is working.
        //Not very random but that's not massively important.

        r = rand() & 0xF8;
        g = rand() & 0xFC;
        b = rand() & 0xF8;

        sendUARTCol(uart0, r, g, b);

        uint32_t pixelCol = urgb_u32(r, g, b);

        put_pixel(pixelCol);

        while(gpio_get(20));
        sleep_ms(200);
        while(!gpio_get(20));
    }
}